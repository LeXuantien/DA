/// <reference types="expo-router/types" />

// NOTE: This file should not be edited and should be in your git ignore